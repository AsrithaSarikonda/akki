package com.capgemini.paymentwallet.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Iterator;
import com.capgemini.paymentwallet.bean.Customer;
import com.capgemini.paymentwallet.bean.Wallet;
import com.capgemini.paymentwallet.service.PaymentWalletService;
import com.capgemini.paymentwallet.service.PaymentWalletValidation;

public class Client {
    public static void main(String[] args) {
		int choice = 0;
		
		do {
			int choice1=0;
			Scanner scan = new Scanner(System.in);
			System.out.println("....................WELCOME TO PAYMENT WALLET APPLICATION..................");
			System.out.println("1. SIGNUP ");
			System.out.println("2. LOGIN ");
			System.out.println("3. EXIT ");
			System.out.println("      Enter your choice :  ");
			choice= scan.nextInt();
			switch(choice)
			{
			case 1:
				createAccount();
				break;
			case 2:
				boolean b= loginAccount();
				if(b)
				{
					do {
						printDetails();
						choice1= scan.nextInt();
						switch(choice1)
						{
						case 1 : 
							showBalance();
							break;
						case 2:
							depositAmount();
							break;
						case 3 : 
							withdrawAmount();
							break;
						case 4:
							fundTransfer();
							break;
						case 5:
							printTransaction();
							break;
					}
				}while(choice1!=6);
			}
			else
				{
					System.out.println("                  INVALID LOGIN DETAILS..TRY AGAIN !!        ");
				}
			break;
			
			default :
				System.out.println("               ENTER CORRECT CHOICE         ");
				break;
			
			}
		}while(choice!=3);
	}
	
	private static void printDetails() {
		// TODO Auto-generated method stub
		System.out.println("       Menu     ");
		System.out.println("__________________");	
		System.out.println("1. SHOW BALANCE ");
		System.out.println("2. DEPOSIT AMOUNT ");
		System.out.println("3. WITHDRAW AMOUNT ");
		System.out.println("4. FUND TRANSFER ");
		System.out.println("5. PRINT TRANSACTION ");
		System.out.println("6. SIGN OUT ");
		System.out.println("____________________");
		System.out.println("ENTER YOUR CHOICE");
	}

    public static void createAccount()
	{
		Wallet wallet = new Wallet();
		Customer account = new Customer();
		
		PaymentWalletService service = new PaymentWalletService();
		PaymentWalletValidation validate = new PaymentWalletValidation();
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your UserName ");
		String uName = scanner.nextLine();
		boolean isValidUserName = validate.validateUserName(uName);
		
		System.out.println("Enter your Password");
		String uPassword = scanner.nextLine();
		boolean isValidPassword = validate.validateUserPassword(uPassword);
		
		System.out.println("Enter Customer Name");
		String custName = scanner.nextLine();
		boolean isValidCustName = validate.validateCustomerName(custName);
		
		System.out.println("Enter Customer Age");
		int age = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("Enter Customer gender");
		String gender = scanner.nextLine();
		boolean isValidGender = validate.validateGender(gender);
		
		System.out.println("Enter Customer Mobile Number");
		String custMobileNo = scanner.nextLine();
		boolean isValidMobileNo = validate.validateMobileNo(custMobileNo);
		
		System.out.println("Enter Customer Address");
		String custAddress = scanner.nextLine();
		
		System.out.println("Enter Customer EmailID");
		String custEmail = scanner.nextLine();
		
		System.out.println("Enter Opening Blanace");
		float custInitBal = scanner.nextFloat();
		boolean isValidCustInitBal = validate.validateCustInitBal(custInitBal);
		
		int custAccNo = (int)(Math.random() * 123456+123456);
		LocalDate custAccOpenDate = LocalDate.now();
		
		if(isValidMobileNo &&  isValidCustInitBal
				&& isValidUserName && isValidPassword && isValidCustName 
				&& isValidGender)
		{
			
			account.setuName(uName);
			account.setuPassword(uPassword);
			account.setCustName(custName);
			account.setAge(age);
			account.setGender(gender);
			account.setCustAddress(custAddress);
			account.setCustEmail(custEmail);
			account.setCustMobileNo(custMobileNo);
			
			wallet.setCustAccDate(custAccOpenDate);
			wallet.setCustAccNo(custAccNo);
			wallet.setCustBal(custInitBal);
			wallet.setCustomerDetails(account);
			
			boolean b = service.addWalletDetails(wallet);
			if(b)
			{
				
				System.out.println("Account Created.. Account Number is: "+custAccNo);
				System.out.println("Your UserName is: "+uName);
				System.out.println("Your Password is :"+uPassword);
				
			}else {
				System.out.println("Account Not Created");
			}
	    }
		else {
			if(!isValidUserName) {
				System.out.println("Invalid UserName \n UserName cannot be less than 8 character");
	        }
			if(!isValidPassword) {
				System.out.println("Invalid Password\n Password cannot be less than 5 character");
			}
			if(!isValidCustName) {
				System.out.println("Customer Name Can contain only Letters");
			}
			
			if(!isValidGender) {
				System.out.println("Invalid Gender");
			}
			
			if(!isValidMobileNo) {
				System.out.println("Invalid Mobile Nuber \n Mobile No should be 10 character long and can contain only numbers");
			}
			if(!isValidCustInitBal) {
				System.out.println("Invalid Initial Balance\n Balance should be greater than 500");
			}
		}
	}
	
    public static void showBalance()
	{
		PaymentWalletService service = new PaymentWalletService();
		float balance = service.showBalance();
		System.out.println("Account Balance is: "+balance);
	}
	
	public static void depositAmount()
	{
		Scanner scanner = new Scanner(System.in);
		PaymentWalletService service = new PaymentWalletService();
		System.out.println("Enter amount to deposit");
		float amount = scanner.nextFloat();
		boolean isDeposit = service.depositAmount(amount);
		if(isDeposit)
		{
			System.out.println("Amount Deposited in your account");
		}
	}
	
	public static void withdrawAmount()
	{
		Scanner scanner = new Scanner(System.in);
		PaymentWalletService service = new PaymentWalletService();
		
		System.out.println("Enter Amount to withdraw :  ");
		float amount = scanner.nextFloat();
		boolean isDeposit = service.withdrawAmount(amount);
		
		if(isDeposit) {
			System.out.println("Amount Withdraw from your account");
		}
	}
	
	public static boolean loginAccount()
	{
		Scanner scanner = new Scanner(System.in);
		PaymentWalletService service = new PaymentWalletService();
		System.out.println("Enter Your Username");
		String uName = scanner.nextLine();
		System.out.println("Enter Your Password");
		String uPassword = scanner.nextLine();
		boolean b= service.loginAccount(uName, uPassword);
		if(b) {
			return true;
		}
		return false;
	}
	
	public static void fundTransfer()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println(" Enter Account Number to transfer amount");
		int accNo = scanner.nextInt();
		System.out.println("Enter Amount to Transfer");
		float amount = scanner.nextFloat();
		PaymentWalletService service = new PaymentWalletService();
		boolean b= service.fundTransfer(accNo,amount);
		if(b) {
			System.out.println("Fund Transfered Successfully");
		}
		else {
			System.out.println("Enter Correct Input");
		}
	}
	
	public static void printTransaction()
	{
		PaymentWalletService service = new PaymentWalletService();;
		List<String> l1=service.printTransaction();
		Iterator<String> it=l1.iterator();
		while(it.hasNext()) {
			String s= it.next();
			System.out.println(s);
	    }
	}

}
