package com.cg.paymentwallet.ui.PaymentWallet;

import com.cg.paymentwallet.dto.PaymentWallet.CustomerDto;
import com.cg.paymentwallet.exception.PaymentWallet.WalletException;
import com.cg.paymentwallet.service.PaymentWallet.Service;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class MyMainApplicationTest 
    extends TestCase
{
   
   public void testName() throws WalletException {
	   Service s1 = new Service();
	   boolean actualReturnValue = s1.validateName("Dhoni");
	   Assert.assertEquals(false, actualReturnValue);
   }
   
   
   public void testNumber() throws WalletException {
	   Service s1 = new Service();
	   boolean actualReturnValue1 = s1.validatePhoneNumber("9876543210");
	   Assert.assertEquals(false, actualReturnValue1);
   }
   
   
   public void testAddDetails() {
	   CustomerDto dto = new CustomerDto();
	   Service service = new Service();
	   dto.setCustomerName("Dhoni");
	   dto.setPhoneNumber("9876543210");;
	   dto.setEmail("dhoni@gmail.com");
   }
}
