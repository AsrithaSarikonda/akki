package com.cg.paymentwallet.ui.PaymentWallet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.paymentwallet.dto.PaymentWallet.CustomerDto;
import com.cg.paymentwallet.exception.PaymentWallet.WalletException;
import com.cg.paymentwallet.service.PaymentWallet.IService;
import com.cg.paymentwallet.service.PaymentWallet.Service;

/**
 * Hello world!
 *
 */
public class MyMainApplication 
{
    public static void main( String[] args ) throws WalletException
    {
       Scanner scanner = new Scanner(System.in);
       IService service = new Service();
       CustomerDto customerDto = new CustomerDto();
       int choice = 0;
      // long accountNumber = (long) Math.random(); 
      
       printDetails();
      switch(choice) {
      case 1:
    	  System.out.println("Enter name :");
          String name = scanner.next();
          System.out.println("Enter phone number: ");
          String phnNum = scanner.next();
          System.out.println("Enter email id : ");
          String email = scanner.next();
          boolean result = true;
          while(result) {
        	  boolean flag = service.validateName(name);
        	  if(flag) {
        		  customerDto.setCustomerName(name);
        		  break;
        	  }
        	  else {
        		  System.out.println("Enter Valid Username");
        		  result = true;
        	  }
          }
          while(result) {
        	  boolean flag1 = service.validatePhoneNumber(phnNum);
        	  if(flag1) {
        		  customerDto.setPhoneNumber(phnNum);
        		  break;
        	  }else {
        		  System.out.println("Enter Valid mobile number");
        		  result = true;
        	  }
          }
          while(result) {
        	  boolean flag2 = service.validateEmail(email);
        	  if(flag2) {
        		  customerDto.setEmail(email);
        		  break;
        	  }else {
        		  System.out.println("Enter Valid email ID");
        		  result = true;
        	  }
          }
          long accountNumber = service.createAccount(customerDto);
          if(accountNumber != 0) {
        	  System.out.println("Successfully created and your account number is: "+accountNumber);
        	  break;
          }
          
      case 2:
    	  System.out.println("Enter Account Number");
		  long accountNumberOne = scanner.nextLong();
		  customerDto=service.display(accountNumberOne);
		  if(customerDto != null) {
			  System.out.println("Customer Name "+customerDto.getCustomerName());
			  System.out.println("Customer Phone number "+customerDto.getPhoneNumber());
			  System.out.println("Customer email "+customerDto.getEmail());
			  System.out.println("Available Balance "+customerDto.getBalance());
		  }
		  break;
    	  
      case 3:
    	  try {
    		  System.out.println("Enter Account Number");
    		  long accountNumberTwo = scanner.nextLong();
    		  System.out.println("Enter amount to be deposited ");
    		  double amount = scanner.nextDouble();
    		  CustomerDto customerDto1 = service.Deposit(amount, accountNumberTwo);
    		  System.out.println("Total amount "+customerDto1.getBalance());
    		  break;
    	  }
    	  catch(Exception e) {
    		  System.out.println(e.getMessage());
    	  }
      case 4 :
    	  try {
    		  System.out.println("Enter Account Number");
    		  long accountNumberThree = scanner.nextLong();
    		  System.out.println("Enter Amount to withdraw ");
    		  double amount = scanner.nextDouble();
    		  CustomerDto customerDto2 = service.display(accountNumberThree);
    		  double balance = customerDto2.getBalance();
    		  CustomerDto customerDto3 = service.Withdraw(amount, accountNumberThree);
    		  if(balance != customerDto3.getBalance())
    			  System.out.println("total amount after withdraw "+customerDto3.getBalance());
    		  else {
    			  System.out.println("No Sufficient funds");
    			  System.out.println("Amount in your account= "+customerDto2.getBalance());
    		  }
    		  break;
    	  }
    	  catch(Exception e) {
    		  System.out.println(e.getMessage());
    	  }
      case 5:
    	  try {
    		  System.out.println("Enter Account Number");
    		  long accountNumberfour = scanner.nextLong();
    		  ArrayList<String> list = service.printTransactions(accountNumberfour);
    		  Iterator itr = list.iterator();
    		  while(itr.hasNext()) {
    			  System.out.println(itr.next());
    		  }
    	  }catch(Exception e) {
    		  System.out.println(e.getMessage());
    	  }
    	  
      case 6:
    	  try {
    		  System.out.println("Enter sender Account Number");
    		  long accountNumberSender = scanner.nextLong();
    		  System.out.println("Enter receiver Account Number");
    		  long accountNumberReceiver = scanner.nextLong();
    		  System.out.println("Enter amount to be transfered");
    		  double amount = scanner.nextDouble();
    		  boolean flag = service.fundTransfer(accountNumberSender, accountNumberReceiver, amount);
    		  if(flag)
    			  System.out.println("Fund Transfer Successfull!!");
    		  else 
    			  System.out.println("Fund Transfer Failure");
    	  }catch(Exception e) {
    		  System.out.println(e.getMessage());
    		  
    	  }
      case 7:
    	  System.exit(0);
    	  break;
    	  
      }
     }

	private static void printDetails() {
		// TODO Auto-generated method stub
		System.out.println("ENTER YOUR CHOICE: ");
	    System.out.println("1. Create Account");
	    System.out.println("2. Show Balance");
	    System.out.println("3. Deposit");
	    System.out.println("4. Withdraw");
	    System.out.println("5. Funds Transfer");
	    System.out.println("6. Print Transactions");
	    System.out.println("7. Exit");
	}
}