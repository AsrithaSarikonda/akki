package com.cg.paymentwallet.dto.PaymentWallet;

public class CustomerDto {
	private String customerName;
	private String phoneNumber;
	private double balance; 
public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	//	private String password;
	private String email;
	private long accountNumber;

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CustomerDto(String customerName, String phoneNumber, double balance, String email, long accountNumber) {
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.balance = balance;
		this.email = email;
		this.accountNumber = accountNumber;
	}
	public CustomerDto() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
