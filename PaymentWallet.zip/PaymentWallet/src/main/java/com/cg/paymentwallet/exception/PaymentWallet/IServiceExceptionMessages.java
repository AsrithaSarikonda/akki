package com.cg.paymentwallet.exception.PaymentWallet;

public interface IServiceExceptionMessages {
	  String MESSAGE1 = "Name should contain only alphabets ";
	  String MESSAGE2 = "Phone number should contain numbers and of 10 digits";
	  String MESSAGE3 = "Email should be valid";
}
