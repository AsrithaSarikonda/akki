package com.cg.paymentwallet.exception.PaymentWallet;

public class WalletException extends Exception {

	public WalletException() {
		super();
		// TODO Auto-generated constructor stub
	}
    public WalletException(String msg) {
    	super(msg);
    }
}
