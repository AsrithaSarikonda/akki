package com.cg.paymentwallet.service.PaymentWallet;

import java.util.ArrayList;

import com.cg.paymentwallet.dto.PaymentWallet.CustomerDto;
import com.cg.paymentwallet.exception.PaymentWallet.WalletException;

public interface IService {
     public boolean validateName(String name) throws WalletException;
     public boolean validatePhoneNumber(String phoneNumber) throws WalletException;
     public boolean validateEmail(String email)throws WalletException ;
     public CustomerDto display(long accountNumberOne);
     public CustomerDto Deposit(double amount,long accountNumber);
     public CustomerDto Withdraw(double amount,long accountNumber);
     public ArrayList<String> printTransactions(long accountNumber);
     public boolean fundTransfer(long accountNumberSender,long accountNumberReceiver,double amount);
	public long createAccount(CustomerDto customerDto);
}


