package com.cg.paymentwallet.service.PaymentWallet;

import java.util.ArrayList;

import com.cg.paymentwallet.dto.PaymentWallet.CustomerDto;
import com.cg.paymentwallet.exception.PaymentWallet.IServiceExceptionMessages;
import com.cg.paymentwallet.exception.PaymentWallet.WalletException;

public class Service implements IService{
    CustomerDto customerDto = new CustomerDto();
	public boolean validateName(String name) throws WalletException {
		boolean result = true;
		if(!customerDto.getCustomerName().matches("[A-Z[a-z]")) {
			throw new WalletException(IServiceExceptionMessages.MESSAGE1);
		}
		return result;
 	}

	public boolean validatePhoneNumber(String phoneNumber) throws WalletException {
		boolean result = true;
		if(!customerDto.getPhoneNumber().matches("[0-9]+") && customerDto.getPhoneNumber().length() == 10) {
			throw new WalletException(IServiceExceptionMessages.MESSAGE2);
		}
		return result;
	}

	public boolean validateEmail(String email) throws WalletException {
		boolean result = true;
		if(!customerDto.getEmail().matches("[a-zA-Z0-9_.]*@[a-z0-9]*.com")) {
			throw new WalletException(IServiceExceptionMessages.MESSAGE3);
		}
		return result;
	}

	public CustomerDto display(long accountNumber) {
		
		
		return null;
	}

	public CustomerDto Deposit(double amount, long accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerDto Withdraw(double amount, long accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<String> printTransactions(long accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean fundTranfer(long accountNumberSender, long accountNumberReceiver, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	public long createAccount(CustomerDto customerDto) {
		// TODO Auto-generated method stub
		return 0;
	}

	public CustomerDto Deposit(double amount, String accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public CustomerDto Withdraw(double amount, String accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<String> printTransactions(String accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean fundTransfer(long accountNumberSender, long accountNumberReceiver, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
