package com.capg.WalletApp.service;

import java.util.List;

import com.capg.WalletApp.bean.Customer;



public interface IWalletApplicationService {
	public int createAccount(Customer customer) throws Exception;
	public boolean login(String username, String password) throws Exception;
	public float showBalance();
	public int deposit(float amount);
	public int withdraw(float amount);
	public int fundTransfer(int accNo, float amount);
	public void printTransaction();
	

}
