package com.cg.sevensix.ui;

import java.util.Scanner;

import com.cg.sevensix.bean.EmployeeBean;
import com.cg.sevensix.service.EmployeeServiceImpl;
import com.cg.sevensix.service.IEmployeeService;

public class MyMainApplication {

	public static void main(String[] args) throws Exception {
		 int ch = 0;
 	    IEmployeeService service = new EmployeeServiceImpl();
 	    
 	    do {
 	     printDetails();
 	     System.out.println("Enter Choice");
 	     Scanner sc = new Scanner(System.in);
 	     ch = sc.nextInt();
 	     switch (ch) {
 	     case 1:
 	      int employeeId;
 	      System.out.println("Enter Employee Id");
 	      int eid = sc.nextInt();
 	      System.out.println("Enter Employee Name");
 	      String ename = sc.next();
 	      System.out.println("Enter Employee Salary");
 	      float esal = sc.nextFloat();
 	      
 	      EmployeeBean emp = new EmployeeBean();
 	      emp.setEid(eid);
 	      emp.setEname(ename);
 	      emp.setEsal(esal);
 	      employeeId = service.addEmployee(emp);
	      System.out.println("Succesfull");
    	  System.out.println("Patient Information stored succesfully for "+employeeId);
		  System.out.println("ID: "+emp.getEid());
		  System.out.println("Name: "+emp.getEname());
		  System.out.println("Salary: "+emp.getEsal());
 	      break;
 	     
 	     case 2:
 	      System.out.println("Enter Employee ID");
 	      int eid1 = sc.nextInt();
 	      service.deleteEmployee(eid1);
 	      break;                          
 	     
 	     case 3:
 	        EmployeeBean employee = new EmployeeBean();
			System.out.print("\nEnter Employee Id : ");
			int empId = sc.nextInt();
			employee = service.getEmployeeId(empId);
			System.out.println("----------------------------------------------------------");
			System.out.println("Employee Id : "+employee.getEid());
			System.out.println("Name : "+ employee.getEname());
			System.out.println("Salary : "+employee.getEsal());
			System.out.println("----------------------------------------------------------");
			break;
		
 	    case 4:
 	        System.out.println("EXIT");
 	        System.exit(0);
 	        break;    
 	        
 	    default:
 	    	System.out.println("Enter correct choice");
 	    	break;
 	    }
 	 }while(ch <= 4);
   }
   private static void printDetails() {
 	    System.out.println("1.ADD EMPLOYEE");
 	    System.out.println("2.DELETE EMPLOYEE");
 	    System.out.println("3.DISPLAY EMPLOYEE DETAILS");
 	    System.out.println("4.EXIT");
	}
}
