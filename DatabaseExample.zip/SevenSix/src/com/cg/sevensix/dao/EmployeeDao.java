package com.cg.sevensix.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.sevensix.bean.EmployeeBean;
import com.cg.sevensix.exception.EmployeeException;
import com.cg.sevensix.util.DBUtil;

public class EmployeeDao implements IEmployeeDao {
	Connection con = null;

	public EmployeeDao()  {
		try {
			con = DBUtil.getConnect();
		} catch (EmployeeException e) {
		  e.printStackTrace();
		}
	}

	@Override
	public int addEmployee(EmployeeBean emp) throws Exception {
		int employeeId = 10;
		try {
			employeeId = emp.getEid(); // Getting Unique Employee Id 
			String sql = "INSERT INTO Employee1 VALUES(?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, employeeId);
			pstmt.setString(2, emp.getEname());
			pstmt.setDouble(3, emp.getEsal());

			int row = pstmt.executeUpdate();
			if (row > 0) {
				System.out.println("New Entry -> Employee ID: " + employeeId + "\n Employee Name : " + emp.getEname()
						+ "\n Employee Salary : " + emp.getEsal());
			}

		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		}

		return employeeId;
	}

	@Override
	public void deleteEmployee(int eid) throws Exception {
		try {
	    String sql = "Delete from Employee1 where ID = ?";
	    PreparedStatement pstmt = con.prepareStatement(sql);
	    pstmt.setInt(1, eid);
	    int row = pstmt.executeUpdate();
	    if (row > 0) {
			System.out.println("Deleted Entry -> Employee ID: " + eid);
		}
		} catch(SQLException e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public EmployeeBean getEmployeeId(int empId) throws Exception{
		EmployeeBean empBean = new EmployeeBean();
		try {
		    String sql = "Select * from Employee1 WHERE ID = ?";
		    PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, empId);
            ResultSet res = pstmt.executeQuery();

            if(res.next()) {
	    		empBean.setEid(res.getInt(1));
	    		empBean.setEname(res.getString(2));
	    		empBean.setEsal(res.getFloat(3));
	    	}
			} catch(SQLException e) {
				throw new Exception(e.getMessage());
			}
		return empBean;
	}

}
