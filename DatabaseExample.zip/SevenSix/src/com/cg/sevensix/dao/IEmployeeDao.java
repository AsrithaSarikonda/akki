package com.cg.sevensix.dao;

import com.cg.sevensix.bean.EmployeeBean;

public interface IEmployeeDao {

	int addEmployee(EmployeeBean emp) throws Exception;
	public void deleteEmployee(int eid) throws Exception;
	EmployeeBean getEmployeeId(int empId) throws Exception;
}
