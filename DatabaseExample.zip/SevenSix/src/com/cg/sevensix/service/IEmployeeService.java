package com.cg.sevensix.service;

import java.util.Set;

import com.cg.sevensix.bean.EmployeeBean;

public interface IEmployeeService {
	public int addEmployee(EmployeeBean emp) throws Exception;
	public void deleteEmployee(int eid)throws Exception;
    public EmployeeBean getEmployeeId(int empId) throws Exception;
}
