package com.cg.sevensix.service;


import com.cg.sevensix.bean.EmployeeBean;
import com.cg.sevensix.dao.EmployeeDao;
import com.cg.sevensix.dao.IEmployeeDao;

public class EmployeeServiceImpl implements IEmployeeService {
    IEmployeeDao dao = null;

	public EmployeeServiceImpl() {
		dao = new EmployeeDao();
	}

	@Override
	public int addEmployee(EmployeeBean emp) throws Exception {
		return dao.addEmployee(emp);

	}
    
	@Override
	public void deleteEmployee(int eid) throws Exception{
	     dao.deleteEmployee(eid);      
	}

	@Override
	public EmployeeBean getEmployeeId(int empId) throws Exception {
		return dao.getEmployeeId(empId);
	}

}

