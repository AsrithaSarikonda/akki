package com.cg.service;

import java.math.BigDecimal;

import com.cg.bean.Customer;

public interface WalletService {

	public Customer createAccount(String name, String mobileNo, BigDecimal amount);

	public Customer showBalance(String mobileNo);

	public Customer fundTransfer(String sourceMob, String targetMob, BigDecimal amount);

	public Customer depositAmount(String mobileNo, BigDecimal amount);

}
