package com.cg.repo;

import com.cg.bean.Customer;

public interface WalletRepo {

	public boolean save(Customer customer);

	public Customer findOne(String mobileNo);
}
